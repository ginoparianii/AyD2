package com.servidor;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

public class GUI extends JFrame {
    private static GUI instance;    //instancia unica ya que es del singleton 
    SensorData sensor = new SensorData();
    JPanel panelLED = new JPanel();
    JLabel imagenLabel = new JLabel();
    Riego riego = new Riego();
    private JLabel estadoLabel;
    private ImageIcon imagenApagado;
    private ImageIcon imagenEncendido;
    private ImageIcon imagenRiegoOn;
    private ImageIcon imagenRiegoOff;

    private ScheduledExecutorService scheduler;

    //Agrega referencias a los componentes de la interfaz que se actualizarán
    private JTextField tempActualField;
    private JTextField humActualField;
    

    public GUI() {
        configurarVentana();
        cargarImagenes();
        agregarPaneles();
        actualizarGUI();
    }

    public static GUI getInstance(){
        if( instance == null){
            instance = new GUI();
        }
        return instance;
    }

    private void configurarVentana() {
        setTitle("Sistema de Monitoreo de Temperatura y Humedad");
        setSize(1680, 820);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
    }

    private void cargarImagenes() {
        imagenApagado = new ImageIcon("C:\\Users\\ginop\\Desktop\\UNLPam\\Análisis y Diseño de Sistemas II\\Proyecto Final\\Servidor e Interfaz\\Servidor e Interfaz\\servidor_interfaz\\src\\main\\resources\\RiegoApagado.png");
        imagenEncendido = new ImageIcon("C:\\Users\\ginop\\Desktop\\UNLPam\\Análisis y Diseño de Sistemas II\\Proyecto Final\\Servidor e Interfaz\\Servidor e Interfaz\\servidor_interfaz\\src\\main\\resources\\RiegoEncendido.png");
        imagenRiegoOn = new ImageIcon("C:\\Users\\ginop\\Desktop\\UNLPam\\Análisis y Diseño de Sistemas II\\Proyecto Final\\Servidor e Interfaz\\Servidor e Interfaz\\servidor_interfaz\\src\\main\\resources\\RiegoOn.png"); 
        imagenRiegoOff = new ImageIcon("C:\\Users\\ginop\\Desktop\\UNLPam\\Análisis y Diseño de Sistemas II\\Proyecto Final\\Servidor e Interfaz\\Servidor e Interfaz\\servidor_interfaz\\src\\main\\resources\\Riego.png");
    }

    private void agregarPaneles() {
        add(crearPanelIzquierdo(), BorderLayout.WEST);
        add(crearPanelCentro(), BorderLayout.CENTER);
        add(crearPanelDerecho(), BorderLayout.EAST);
    }

    private JPanel crearPanelIzquierdo() {
        JPanel panelIzquierdo = new JPanel(new GridLayout(2, 1, 10, 10));
        panelIzquierdo.setPreferredSize(new Dimension(200, 0));
        panelIzquierdo.add(crearPanelAjusteTemp());
        panelIzquierdo.add(crearPanelAjusteHum());
        return panelIzquierdo;
    }

    private JPanel crearPanelAjusteTemp() {
        // Método que crea el panel de ajustes de temperatura
        JPanel panelAjusteTemp = new JPanel();
        panelAjusteTemp.setLayout(new GridLayout(5, 2));
        panelAjusteTemp.setBorder(BorderFactory.createTitledBorder("  AJUSTES DE TEMPERATURA"));

        JLabel labelTemp = new JLabel("Temp Actual:");

        // Crear el campo de texto para mostrar la temperatura actual
        tempActualField = new JTextField(String.valueOf(sensor.obtenerTemp()));
        tempActualField.setHorizontalAlignment(JTextField.CENTER);
        tempActualField.setEditable(false);

        // Actualizar el color inicial
        // actualizarColorTemperatura(sensor.obtenerTemp());

        // Crear los campos para el rango de temperatura superior e inferior
        JLabel labelRangoSuperiorTemp = new JLabel("Rango Superior:");
        JTextField fieldRangoSuperiorTemp = new JTextField("30");
        fieldRangoSuperiorTemp.setHorizontalAlignment(JTextField.CENTER);

        JLabel labelRangoInferiorTemp = new JLabel("Rango Inferior:");
        JTextField fieldRangoInferiorTemp = new JTextField("18");
        fieldRangoInferiorTemp.setHorizontalAlignment(JTextField.CENTER);

        // Agregar los componentes al panel de ajuste de temperatura
        panelAjusteTemp.add(labelTemp);
        panelAjusteTemp.add(tempActualField);
        panelAjusteTemp.add(labelRangoSuperiorTemp);
        panelAjusteTemp.add(fieldRangoSuperiorTemp);
        panelAjusteTemp.add(labelRangoInferiorTemp);
        panelAjusteTemp.add(fieldRangoInferiorTemp);

        // Crear un ScheduledExecutorService para actualizar el campo de temperatura
        // cada 5 segundos
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(() -> {
            // Obtener la temperatura actual
            double tempActual = sensor.obtenerTemp();

            // Actualizar el valor en el campo de texto
            tempActualField.setText(String.valueOf(tempActual));

            // Actualizar el color según el valor de temperatura
            if (tempActual > 30) {
                tempActualField.setBackground(Color.RED);
            } else if (tempActual >= 18 && tempActual <= 30) {
                tempActualField.setBackground(Color.GREEN);
            } else {
                tempActualField.setBackground(Color.BLUE);
            }

            // Refrescar el campo de texto
            tempActualField.revalidate();
            tempActualField.repaint();

        }, 0, 5, TimeUnit.SECONDS);

        return panelAjusteTemp;
    }

    private JPanel crearPanelAjusteHum() {
        JPanel panelAjusteHum = new JPanel();
        panelAjusteHum.setLayout(new GridLayout(5, 2));
        panelAjusteHum.setBorder(BorderFactory.createTitledBorder("  AJUSTES DE HUMEDAD"));

        JLabel labelHum = new JLabel("Hum Actual:");

        // Crear el campo de texto para mostrar la temperatura actual
        humActualField = new JTextField(String.valueOf(sensor.obtenerHum()));
        humActualField.setHorizontalAlignment(JTextField.CENTER);
        humActualField.setEditable(false);

        // Crear los campos para el rango de temperatura superior e inferior
        JLabel labelRangoSuperiorHum = new JLabel("Rango Superior:");
        JTextField fieldRangoSuperiorHum = new JTextField("50");
        fieldRangoSuperiorHum.setHorizontalAlignment(JTextField.CENTER);

        JLabel labelRangoInferiorHum = new JLabel("Rango Inferior:");
        JTextField fieldRangoInferiorHum = new JTextField("0");
        fieldRangoInferiorHum.setHorizontalAlignment(JTextField.CENTER);

        // Agregar los componentes al panel de ajuste de temperatura
        panelAjusteHum.add(labelHum);
        panelAjusteHum.add(humActualField);
        panelAjusteHum.add(labelRangoSuperiorHum);
        panelAjusteHum.add(fieldRangoSuperiorHum);
        panelAjusteHum.add(labelRangoInferiorHum);
        panelAjusteHum.add(fieldRangoInferiorHum);

        // Crear un ScheduledExecutorService para actualizar el campo de temperatura
        // cada 5 segundos
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(() -> {
            // Obtener la temperatura actual
            double humActual = sensor.obtenerHum();

            // Actualizar el valor en el campo de texto
            humActualField.setText(String.valueOf(humActual));

            // Actualizar el color según el valor de temperatura
            if (humActual >= 0) {
                humActualField.setBackground(Color.YELLOW);
              
            } else if (humActual >= 50 && humActual <= 80) {
                humActualField.setBackground(Color.ORANGE);
            } else {
                System.setProperty("verdeMusgo", "0x808000");
                Color verdeMusgo = Color.getColor("verdeMusgo", Color.BLACK);
                humActualField.setBackground(verdeMusgo);
            }

            // Refrescar el campo de texto
            humActualField.revalidate();
            humActualField.repaint();

        }, 0, 5, TimeUnit.SECONDS);

        return panelAjusteHum;
    }
    

    private JPanel crearPanelCentro() {
        ScheduledExecutorService scheduler;
        scheduler = Executors.newScheduledThreadPool(1);
        JPanel panelCentro = new JPanel();
        panelCentro.setLayout(new BorderLayout());
        panelCentro.setBorder(BorderFactory.createTitledBorder("HISTORIAL DE MEDICIONES"));

        String[] columnNames = { "Temperatura", "Humedad", "Hora", "Fecha" };
        Object[][] data = new Object[46][4];

        // Crear el DefaultTableModel
        DefaultTableModel tableModel = new DefaultTableModel(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable tableHistorial = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(tableHistorial);
        panelCentro.add(scrollPane, BorderLayout.CENTER);

        final int[] i = { 0 };

        //Formateadores para la hora y fecha
        DateTimeFormatter formatoHora = DateTimeFormatter.ofPattern("HH:mm:ss");
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        //Programar tarea para ejecutar cada 5 segundos
        scheduler.scheduleAtFixedRate(() -> {
            //Obtener la fecha y hora actuales en cada iteración
            LocalDateTime fechaHoraActual = LocalDateTime.now();

            //Actualizar los valores en la tabla
            tableModel.setValueAt(sensor.obtenerTemp(), i[0], 0);
            tableModel.setValueAt(sensor.obtenerHum(), i[0], 1);
            tableModel.setValueAt(fechaHoraActual.format(formatoHora), i[0], 2);
            tableModel.setValueAt(fechaHoraActual.format(formatoFecha), i[0], 3);

            //Incrementar el índice y reiniciar si llega a 9
            i[0]++;
            if (i[0] == 46) {
                i[0] = 0;
            }

            //Refrescar la tabla
            tableModel.fireTableDataChanged();

        }, 0, 5, TimeUnit.SECONDS);

        return panelCentro;
    }

    private JPanel crearPanelDerecho() {
        JPanel panelDerecho = new JPanel();
        panelDerecho.setLayout(new GridLayout(5, 1, 0, 0));
        panelDerecho.setPreferredSize(new Dimension(300, 0));

        // Indicadores de estado
        JPanel panelIndicadores = new JPanel();
        panelIndicadores.setLayout(new GridLayout(3, 2));
        panelIndicadores.setBorder(BorderFactory.createTitledBorder("INDICADORES"));
        Font font = new Font("Arial", Font.BOLD, 12);

        JTextField TempAlta = new JTextField("Temp Muy Alta");
        TempAlta.setBackground(Color.RED);
        TempAlta.setFont(font);
        TempAlta.setHorizontalAlignment(JTextField.CENTER);

        JTextField HumAlta = new JTextField("Hum Muy Alta");
        System.setProperty("verdeMusgo", "0x808000");
        Color verdeMusgo = Color.getColor("verdeMusgo", Color.BLACK);
        HumAlta.setBackground(verdeMusgo);
        HumAlta.setFont(font);
        HumAlta.setHorizontalAlignment(JTextField.CENTER);

        JTextField TempAceptable = new JTextField("Temp Aceptable");
        TempAceptable.setBackground(Color.GREEN);
        TempAceptable.setFont(font);
        TempAceptable.setHorizontalAlignment(JTextField.CENTER);

        JTextField HumAceptable = new JTextField("Hum Aceptable");
        HumAceptable.setBackground(Color.GREEN);
        HumAceptable.setFont(font);
        HumAceptable.setHorizontalAlignment(JTextField.CENTER);

        JTextField TempBaja = new JTextField("Temp Baja");
        TempBaja.setBackground(Color.BLUE);
        TempBaja.setFont(font);
        TempBaja.setHorizontalAlignment(JTextField.CENTER);

        JTextField HumedadBaja = new JTextField("Humedad Baja");
        HumedadBaja.setBackground(Color.YELLOW);
        HumedadBaja.setFont(font);
        HumedadBaja.setHorizontalAlignment(JTextField.CENTER);

        panelIndicadores.add(TempAlta);
        panelIndicadores.add(HumAlta);
        panelIndicadores.add(TempAceptable);
        panelIndicadores.add(HumAceptable);
        panelIndicadores.add(TempBaja);
        panelIndicadores.add(HumedadBaja);

        // Crear el gráfico de temperatura
        DefaultCategoryDataset dataset = new DefaultCategoryDataset(); // Dataset para almacenar las temperaturas
        JFreeChart chart = ChartFactory.createLineChart(
                "", // Título del gráfico
                "Tiempo", // Etiqueta del eje X
                "Temperatura", // Etiqueta del eje Y
                dataset, // Datos
                PlotOrientation.VERTICAL,
                true, true, false);

        ValueAxis yAxis = chart.getCategoryPlot().getRangeAxis();
        yAxis.setRange(0.0, 60.0);

        ChartPanel grafTemp = new ChartPanel(chart); // Panel para gráfico de temperatura
        grafTemp.setBorder(BorderFactory.createTitledBorder("Gráfica Temperatura Medida"));

        // Crear el gráfico de humedad
        DefaultCategoryDataset humDataset = new DefaultCategoryDataset();
        JFreeChart humChart = ChartFactory.createLineChart(
                "", 
                "Tiempo", 
                "Humedad", 
                humDataset, 
                PlotOrientation.VERTICAL,
                true, true, false);

        ValueAxis humYAxis = humChart.getCategoryPlot().getRangeAxis();
        humYAxis.setRange(0.0, 100.0);

        ChartPanel grafHum = new ChartPanel(humChart);
        grafHum.setBorder(BorderFactory.createTitledBorder("Gráfica Humedad Medida"));

        //Panel estado del riego
        //JPanel panelLED = new JPanel();
        panelLED.setLayout(new BorderLayout()); 
        panelLED.setBorder(BorderFactory.createTitledBorder("ESTADO DEL RIEGO"));

        //Mostrar imagen RiegoOn/RiegoOff
         /*if(sensor.isTempValida() && sensor.isHumValida()){
           // ImageIcon imagenRiegoOn = new ImageIcon("C:\\Users\\Usuario\\Documents\\FACU\\Analisis y Diseño de sistemas\\Proyecto\\Servidor e Interfaz\\Servidor e Interfaz\\servidor_interfaz\\src\\main\\resources\\RiegoOn.png"); // Cambia por la ruta de tu imagen
           //JLabel imagenLabel = new JLabel(imagenRiegoOn);
            imagenLabel.setHorizontalAlignment(JLabel.CENTER);
            panelLED.add(imagenLabel, BorderLayout.CENTER);
        }
        else{
           // ImageIcon imagenRiegoOff = new ImageIcon("C:\\Users\\Usuario\\Documents\\FACU\\Analisis y Diseño de sistemas\\Proyecto\\Servidor e Interfaz(ult)\\Servidor e Interfaz\\servidor_interfaz\\src\\main\\resources\\Riego.png"); // Cambia por la ruta de tu imagen
            JLabel imagenLabel = new JLabel(imagenRiegoOff);
            imagenLabel.setHorizontalAlignment(JLabel.CENTER);
            panelLED.add(imagenLabel, BorderLayout.CENTER); 
        }*/

        //Panel 4
        imagenLabel.setHorizontalAlignment(JLabel.CENTER);
        panelLED.add(imagenLabel, BorderLayout.CENTER);

        // Panel ultimo 
        estadoLabel = new JLabel();
        estadoLabel.setHorizontalAlignment(JLabel.CENTER);
        //panelLED.add(estadoLabel, BorderLayout.CENTER);

        // Añadir componentes al panel derecho
        panelDerecho.add(panelIndicadores);
        panelDerecho.add(grafTemp); // Gráfico de temperatura
        panelDerecho.add(grafHum);
        panelDerecho.add(panelLED); // Panel LED
        panelDerecho.add(estadoLabel); // Panel de imagen del riego

        // Lista para almacenar temperaturas
        List<Double> temperaturas = new ArrayList<>();
        List<Double> humedades = new ArrayList<>();
        final int maxTemperaturas = 10; // Número máximo de temperaturas a mostrar
        final int maxHumedades = 10;

        // Crear un ScheduledExecutorService para actualizar los paneles cada 5 segundos
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(() -> {

            // Obtener el valor de temperatura actual
            double tempActual = sensor.obtenerTemp();
            double tempActuall = sensor.obtenerHum();

            // Agregar un nuevo valor de temperatura
            temperaturas.add(tempActual);
            humedades.add(tempActuall);

            if (temperaturas.size() > maxTemperaturas) {
                temperaturas.remove(0); // Eliminar la temperatura más antigua
            }

            if (humedades.size() > maxHumedades) {
                humedades.remove(0); // Eliminar la humedad más antigua
            }

            // Actualizar el dataset
            dataset.clear(); // Limpiar el dataset antes de agregar nuevas entradas
            humDataset.clear();

            for (int i = 0; i < temperaturas.size(); i++) {
                dataset.addValue(temperaturas.get(i), "Temperatura", "T" + (i + 1)); // Cambiar el índice para etiquetas
                                                                                     // de T1 a T10
            }

            for (int h = 0; h < humedades.size(); h++) {
                humDataset.addValue(humedades.get(h), "Humedad", "H" + (h + 1)); // Cambiar el índice para etiquetas
                                                                                     // de T1 a T10
            }

            // Actualizar el gráfico
            grafTemp.revalidate();
            grafTemp.repaint();
            grafHum.revalidate();
            grafHum.repaint();
            panelLED.revalidate();
            panelLED.repaint();

            actualizarEstadoRiego();

            // Actualizar el estado del riego (imagen o LED)
            estadoLabel.revalidate();
            estadoLabel.repaint();

        }, 0, 5, TimeUnit.SECONDS);

        return panelDerecho;
    }

    private void actualizarEstadoRiego() {
        if (sensor.isTempValida() == true && sensor.isHumValida() == true) {
            imagenLabel.setIcon(imagenRiegoOn);
            estadoLabel.setIcon(imagenEncendido);
            riego.activar(); // Actualiza el estado del riego a encendido
        } else {
            imagenLabel.setIcon(imagenRiegoOff);
            estadoLabel.setIcon(imagenApagado);
            riego.desactivar(); // Actualiza el estado del riego a apagado
        }
    }

    void actualizarGUI() {
        // Crea un scheduler para ejecutar tareas periódicamente
        scheduler = Executors.newScheduledThreadPool(1);

        // Programa la tarea para que se ejecute cada 2 segundos
        scheduler.scheduleAtFixedRate(() -> {
            sensor.setTempActual(); // Actualiza la temperatura
            sensor.setHumActual(); // Actualiza la humedad

            // Actualiza los componentes de la interfaz
            SwingUtilities.invokeLater(() -> {
                tempActualField.setText(String.valueOf(sensor.obtenerTemp()));
                humActualField.setText(String.valueOf(sensor.obtenerHum()));
                // Actualiza el color del campo de temperatura

                // Actualiza el estado del riego basado en la nueva temperatura
                actualizarEstadoRiego();
            });
        }, 0, 2, TimeUnit.SECONDS); // Inicia inmediatamente y repite cada 2 segundos

    }

}
