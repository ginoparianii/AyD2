package com.servidor;
import static spark.Spark.*;
import java.io.FileWriter;
import java.io.IOException;
import org.json.JSONObject;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.lang.reflect.Field;





public class Controlador {
    public static float temperatura;
    public static float humedad;
    private static final String FILE_PATH = "C:\\Users\\ginop\\Desktop\\UNLPam\\Análisis y Diseño de Sistemas II\\Proyecto Final\\data.txt"; // Cambia por tu ruta deseada

    // Obtener fecha y hora actual
    static LocalDateTime fechaHoraActual = LocalDateTime.now();

    // Formatear la hora
    static DateTimeFormatter formatoHora = DateTimeFormatter.ofPattern("HH:mm:ss");

    // Formatear la fecha
    static DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    // Crear scheduler
    private ScheduledExecutorService scheduler;

    public Controlador() {
        enviarDatos();
        mostrarDatos();
    }

    public void enviarDatos(){
        port(4567); // Establece el puerto en el que se ejecutará el servicio
        ipAddress("0.0.0.0");   // Hace que el servidor escuche en todas las interfaces de red

        post("/data", (request, response) -> {
            // Obtener el cuerpo de la solicitud (que será JSON)
            String body = request.body();
            
            try {
                // Parsear el JSON recibido
                JSONObject jsonData = new JSONObject(body);
                temperatura = jsonData.getFloat("temperatura");
                humedad = jsonData.getFloat("humedad");


                //Simulacion Patron Reflexivo
                SensorData sensor = new SensorData();
                Class c = sensor.getClass();
                Field[] f = c.getFields();
                for(Field field: f){
                    if(field.getName() == "tempActual"){
                        sensor.tempActual = temperatura;
                    }
                    if(field.getName() == "humActual"){
                        sensor.humActual = humedad;
                    }
                }

                // Guardar los datos en un archivo
                
                try (FileWriter file = new FileWriter(FILE_PATH, true)) {
                    file.write("Temperatura: " + temperatura + " °C, Humedad: " + humedad + " % " + " Horario: " + fechaHoraActual.format(formatoHora) + " Fecha: " + fechaHoraActual.format(formatoFecha)+ "\n");
                } catch (IOException e) {
                    e.printStackTrace();
                    response.status(500); // Error de servidor
                    return "Error al escribir en el archivo";
                }

                response.status(200);
                return "Datos guardados correctamente";
            } catch (Exception e) {
                e.printStackTrace();
                response.status(400); // Error de cliente (JSON mal formado, por ejemplo)
                return "Error al procesar los datos";
            }

        });

    }

    public void mostrarDatos() {
    
        scheduler = Executors.newScheduledThreadPool(1);

        // Programa la tarea para que se ejecute cada 5 segundos
        scheduler.scheduleAtFixedRate(() -> {
            // Obtener fecha y hora actual
            LocalDateTime fechaHoraActual2 = LocalDateTime.now();

            // Formatear la hora
            //DateTimeFormatter formatoHora2 = DateTimeFormatter.ofPattern("HH:mm:ss");

            // Formatear la fecha
            DateTimeFormatter formatoFecha2 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            
            get("/verData", (request, response) -> {
                // Obtener fecha y hora actuales
                //String horaActual2 = fechaHoraActual2.format(formatoHora2);
                String fechaActual2 = fechaHoraActual2.format(formatoFecha2);
                // Crear un objeto JSON con la última temperatura y humedad recibida
                JSONObject jsonData = new JSONObject();
                jsonData.put("temperatura", temperatura);
                jsonData.put("humedad", humedad);
                //jsonData.put("hora", horaActual2);
                jsonData.put("fecha", fechaActual2);
    
                // Establecer el tipo de respuesta a JSON
                response.type("application/json");
    
                // Devolver los datos en formato JSON
                return jsonData.toString();
            });

        }, 0, 5, TimeUnit.SECONDS);

        
    }

    public static float obtenerTemp(){
        return temperatura;
    }

    public static float obtenerHum(){
        return humedad;
    }

    
}

