package com.servidor;
import java.util.concurrent.*;


public class SensorData {

    private ScheduledExecutorService scheduler;
    public float tempActual;
    public float humActual;
    public boolean tempValida;
    public boolean humValida;
    public float maxTemp, minTemp;
    public float maxHum, minHum; 
    String filePath  = "C:\\Users\\ginop\\Desktop\\UNLPam\\Análisis y Diseño de Sistemas II\\Proyecto Final\\data.txt"; // Cambia por tu ruta deseada

    public SensorData() {
        minTemp = 18;
        maxTemp = 30;
        minHum = 0;
        maxHum = 50;
        setTempActual();
        setHumActual();
        actualizarDatos();
    }
    
    

    public float obtenerTemp() {
        return this.tempActual;
    }

    public float obtenerHum() {
        return this.humActual;
    }

    public void setTempActual(){
        this.tempActual = Controlador.obtenerTemp();
    }

    public void setHumActual(){
        this.humActual = Controlador.obtenerHum();
    }

    public void actualizarDatos(){
        // Crea un scheduler para ejecutar tareas periódicamente
        scheduler = Executors.newScheduledThreadPool(1);
        
        // Programa la tarea para que se ejecute cada 5 segundos
        scheduler.scheduleAtFixedRate(() -> {
            setTempActual(); // Actualiza la temperatura
            setHumActual();  // Actualiza la humedad
            
        }, 0, 5, TimeUnit.SECONDS); // Inicia inmediatamente y repite cada 5 segundos
    
    }
    
    public void setRangeTemp(float minTemp, float maxTemp){
        this.maxTemp = maxTemp;
        this.minTemp = minTemp;
    }

    public void setRangeHum(float minHum, float maxHum){
        this.maxHum = maxHum;
        this.minHum = minHum;
    }

    public boolean isTempValida(){
        if(tempActual >= minTemp && tempActual <= maxTemp){
            tempValida = true;
        }
        else{
            tempValida = false;
        }
        return tempValida;
    }
    public boolean isHumValida(){
        if(humActual >= minHum && tempActual <= maxHum){
            humValida = true;
        }
        else{
            humValida = false;
        }
        return humValida;
    }

    
}


