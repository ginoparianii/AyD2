package com.servidor;

public class Riego {
    private boolean estado = false; 

    public void activar() {
        estado = true; // Cambia el estado a activo
        System.out.println("Riego activado.");
    }

    public void desactivar() {
        estado = false; // Cambia el estado a inactivo
        System.out.println("Riego desactivado.");
    }

    public boolean getEstado() {
        return estado; // Devuelve el estado actual del riego
    }
}
   
