package com.servidor;

public class Main {
    public static void main(String[] args) {
        
        new Controlador(); 
        GUI gui = GUI.getInstance();
        gui.setVisible(true);
    }
}