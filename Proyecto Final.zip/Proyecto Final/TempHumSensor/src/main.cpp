#include <Arduino.h>
#include <Adafruit_Sensor.h>
#include <DHT.h>
#include <WiFi.h>
#include <HTTPClient.h>


#define DHTPIN 5         // Cambia el pin si es necesario
#define DHTTYPE DHT11               // Tipo de sensor que estamos usando (DHT11)

DHT dht(DHTPIN, DHTTYPE);

void obtenerTempyHum();
void verificarConexion();
void showLecturas();
void enviarDatosAlServidor(float, float);


const char* ssid = "Gino";            // Cambia por el nombre de tu red WiFi
const char* password = "ginopari";    // Cambia por la contraseña de tu red WiFi
const char* serverUrl = "http://192.168.195.152:4567/data";    // URL del servicio REST en el ESP32


float temp;
float hum;
unsigned int tiempo_lectura;



void setup() {
  Serial.begin(115200);
  dht.begin();
  // Conectar a la red WiFi
  WiFi.begin(ssid, password);
  Serial.print("Conectando a ");
  Serial.println(ssid);

  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi conectado");
  Serial.print("Dirección IP: ");
  Serial.println(WiFi.localIP());

  tiempo_lectura = millis();
  
}

void loop(){
  
  if ((millis() - tiempo_lectura) >= 5000 ){
    obtenerTempyHum();
    verificarConexion();
    //showLecturas();
    enviarDatosAlServidor(temp, hum);
    tiempo_lectura = millis();
  }
  
}

void obtenerTempyHum() {
  temp = dht.readTemperature();  // Leer la temperatura directamente en Celsius
  hum = dht.readHumidity();
}

void showLecturas() {
  Serial.print("Temperatura: ");
  Serial.print(temp);
  Serial.print(" °C ");
  Serial.print(" Humedad: ");
  Serial.print(hum);
  Serial.println(" %");
}

void verificarConexion(){
  if (isnan(temp) || isnan(hum)) {    // Verificar si la lectura es válida
    Serial.println("Error al leer la temperatura y/o humedad del sensor DHT!");
    return;
  }
}



void enviarDatosAlServidor(float temp, float hum){
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;

    // Iniciar la conexión con el servidor
    http.begin(serverUrl);

    // Definir el tipo de contenido
    http.addHeader("Content-Type", "application/json");

    // Crear el payload JSON con los datos de temperatura y humedad
    String jsonPayload = "{\"temperatura\": " + String(temp) + ", \"humedad\": " + String(hum) + "}";

    // Realizar la solicitud POST
    int httpResponseCode = http.POST(jsonPayload);

    // Comprobar el resultado de la solicitud
    if (httpResponseCode > 0) {
      String response = http.getString();
      Serial.print("Respuesta del servidor: ");
      Serial.println(response);
    } else {
      Serial.print("Error al realizar el POST: ");
      Serial.println(httpResponseCode);
    }

    // Finalizar la conexión
    http.end();
  } else {
    Serial.println("No conectado a WiFi");
  }
}
